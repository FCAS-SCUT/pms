#ifndef NETWORK_VCARB_H_
#define NETWORK_VCARB_H_

unsigned long VC_MASK[10] = {1, 2, 4, 8, 16, 32, 64, 128, 258, 512};

#endif
