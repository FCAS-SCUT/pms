void readpackage();
int sync(long);
